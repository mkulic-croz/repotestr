![demo](demo.gif)

> Koristio sam `minikube` s `docker` driverom, pa za preuzimanje Docker imagea u minikube koristim `eval $(minikube docker-env)` a zatim `docker build .....`

> Iz istog razloga za potrebno je dodatno pokrenuti [`minikube tunnel`](https://minikube.sigs.k8s.io/docs/commands/tunnel/), jer se LoadBalancer servisima ne dodjeljuju vanjske IP adrese.

## Solucija za rezoluciju `http://server:8000/item`

Najlakši način za rješavanje ovog problema je imenovanje backend servisa kao `server` i tada će se frontend Pod proširiti `server` u `server.default.svc.cluster.local` (FQDN), a zatim će DNS server prevesti `server.default.svc.cluster.local` u IP adresu backend servisa. No ovo nije dobra solucija jer se servis mora zvati `server`.

Bolja solucija je konfigurirati interni DNS server (CoreDNS) u Kubernetesu da znaju kako prevesti `server`. Ovo se može postići konfiguriranjem `CoreDNS` servisa u Kubernetesu (kompletna konfiguracija nalazi se u [coredns-custom.yaml](./coredns-custom.yaml)):

```
rewrite name server.default.svc.cluster.local backend.default.svc.cluster.local
```

Zatim je potrebno apply-ati konfiguraciju:

```bash
kubectl apply -f coredns-custom.yaml
kubectl rollout restart deployment coredns -n kube-system
```

Najbolja solucija je korištenje env varijabli u frontend aplikaciji.
